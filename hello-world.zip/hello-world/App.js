import React, {useState} from 'react';
import {StyleSheet, Button, Image, Text, View} from "react-native";

export default function App() {


    return (
      <View style={styles.container}>
       <Text style={styles.title}>Maria Vitória</Text>
       <Image
            source={require('./assets/pikachu-ga41122f44_1920.png')} style={styles.image}
            />
            <Text>e um Pikachu.</Text>
      </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
      title:{
    fontSize:30
  },
  image:{
    resizeMode: "center",
            height: 200,
            width: 200
  }
})

